﻿using System;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;
using SecretLabs.NETMF.Hardware;
using SecretLabs.NETMF.Hardware.Netduino;

namespace Netduino_Accelerometer
{
    public class Program
    {
        #region Netduino Accelerometer Wiring

        /* 
         
        Netduino    Sparkfun ADXL 335

          A0 -------------- X
          A1 -------------- Y
          A2 -------------- Z
          Gnd ------------ GND
          3v3 ------------ VCC
          Aref ----------- VCC
 
        */

        #endregion Netduino Accelerometer Wiring

        // Define our accelerometer inputs
        static AnalogInput accX;
        static AnalogInput accY;
        static AnalogInput accZ;

        public static void Main()
        {
            // Create the Inputs
            accX = new AnalogInput(Pins.GPIO_PIN_A0);
            accY = new AnalogInput(Pins.GPIO_PIN_A1);
            accZ = new AnalogInput(Pins.GPIO_PIN_A2);

            // Keep application alive via loop
            while (true)
            {
                // Read data from the sensor
                double x = (double)(accX.Read());
                double y = (double)(accY.Read());
                double z = (double)(accZ.Read());

                // Output data to screen
                Debug.Print("X: " + x + " Y: " + y + " Z: " + z);
            }
        }
    }
}
