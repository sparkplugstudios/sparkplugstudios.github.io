﻿using System;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;
using SecretLabs.NETMF.Hardware;
using SecretLabs.NETMF.Hardware.Netduino;

namespace Netduino_FlexSensor
{
    public class Program
    {
        #region Netduino Flex Sensor Wiring

        /* 
                      Flex Sensor
                          | |
                  __ 10k__| |_____
                 |        |       |
                 |        |       |
                Gnd       A0  Vcc + Aref

                Swap the resistor value
                to change scale. This can 
                then be range adjusted

        */

        #endregion Netduino Flex Sensor Wiring

        // Define our flex sensor input
        static AnalogInput flex;

        public static void Main()
        {
            // Create our input
            flex = new AnalogInput(Pins.GPIO_PIN_A0);

            // Set the input range 
            flex.SetRange(180, -180);

            // Keep application alive via loop
            while (true)
            {
                // Read data from the sensor
                double f = (double)(flex.Read());
                // Output data to screen
                Debug.Print("Flex: " + f);
            }
        }
    }
}
