﻿// <copyright file="HeadlightScript.cs" company="dyadica.co.uk">
// Copyright (c) 2010, 2014 All Right Reserved, http://www.dyadica.co.uk

// This source is subject to the dyadica.co.uk Permissive License.
// Please see the http://www.dyadica.co.uk/permissive-license file for more information.
// All other rights reserved.

// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// </copyright>

// <author>SJB</author>
// <email>SJB@dyadica.co.uk</email>
// <date>02.03.2014</date>
// <summary>A MonoBehaviour type class containing several functions which can be utilised 
// to perform control if Ratchets headlights via serial communication within Unity3D</summary>

using UnityEngine;
using System.Collections;

public class HeadlightScript : MonoBehaviour 
{
    // A static reference so that this script can be
    // referenced by others

    public static HeadlightScript Instance;

    // A reference used for quick access to the 
    // UnitySerialPort script.

    private UnitySerialPort unitySerialPort;

    // The current state of both headlights

    bool LeftLightOn = false;
    bool RightLightOn = false;

    /// <summary>
    /// Use this for before initialization
    /// </summary>
    void Awake()
    {
        // Instantiate the static reference to this script

        Instance = this;
    }

    /// <summary>
    /// Use this for initialization
    /// </summary>
    void Start () 
    {
        // Instantiate a refernce to the serial script for 
        // easy access for communication etc.

        if (UnitySerialPort.Instance != null)
            unitySerialPort = UnitySerialPort.Instance;
    }

    /// <summary>
    /// Update is called once per frame
    /// </summary>
	void Update () 
    {

        // If the serialport has not been created then return

        if (unitySerialPort.SerialPort == null || unitySerialPort.SerialPort.IsOpen == false)
            return;

        // Poll for a button input to toggle the status of the
        // left light.

        if (Input.GetButtonDown("LightLeft"))
        {
            // Toggle the status of the light

            LeftLightOn = !LeftLightOn;

            // create a string dependant upon 
            // the status of the light

            string L = "L," + (LeftLightOn ? 1 : 0).ToString();

            // send the command to the serialport

            unitySerialPort.SerialPort.WriteLine(L);
        }

        // Poll for a button input to toggle the status of the
        // right light.

        if (Input.GetButtonDown("LightRight"))
        {
            // Toggle the status of the light

            RightLightOn = !RightLightOn;

            // create a string dependant upon 
            // the status of the light

            string R = "R," + (RightLightOn ? 1 : 0).ToString();

            // send the command to the serialport

            unitySerialPort.SerialPort.WriteLine(R);
        }

        // Poll for a button input to toggle the status of the
        // both the headlights.

        if (Input.GetButtonDown("ToggleLights"))
        {
            // Toggle the status of the lights

            RightLightOn = !RightLightOn; 
            LeftLightOn = !LeftLightOn;

            // create each string dependant upon 
            // the status of the corresponding light

            string R = (RightLightOn ? 1 : 0).ToString();
            string L = (LeftLightOn ? 1 : 0).ToString();

            // send the command to the serialport

            unitySerialPort.SerialPort.WriteLine("L," + L + "," + R);           
        }
	}
}
