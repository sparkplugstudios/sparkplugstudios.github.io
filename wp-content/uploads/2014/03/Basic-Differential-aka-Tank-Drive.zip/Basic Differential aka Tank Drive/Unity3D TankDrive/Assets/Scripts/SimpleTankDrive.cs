﻿// <copyright file="SimpleTankDrive.cs" company="dyadica.co.uk">
// Copyright (c) 2010, 2014 All Right Reserved, http://www.dyadica.co.uk

// This source is subject to the dyadica.co.uk Permissive License.
// Please see the http://www.dyadica.co.uk/permissive-license file for more information.
// All other rights reserved.

// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// </copyright>

// <author>SJB</author>
// <email>SJB@dyadica.co.uk</email>
// <date>25.02.2014</date>
// <summary>A MonoBehaviour type class containing several functions which can be utilised 
// to calculate & perform control of Ratchets tank drive capability within Unity3D</summary>

using UnityEngine;
using System.Collections;

public class SimpleTankDrive : MonoBehaviour 
{
    public static SimpleTankDrive Instance;

    // Storage for the calculated values

    private float rawLeft;
    private float rawRight;

    // The range of the cartesian input

    public float MaxJoy = 1;
    public float MinJoy = -1;

    // The range to be mapped to

    public float MaxValue = 180;
    public float MinValue = 0;

    // The calculated Raw values

    public float RawLeft;
    public float RawRight;

    // The calculated and range mapped values

    public float ValLeft;
    public float ValRight;

    // Static ref to the UnitySerialPort script

    private UnitySerialPort unitySerialPort;

    /// <summary>
    /// Use this for before initialization
    /// </summary>
    void Awake ()
    {
        Instance = this;
    }

    /// <summary>
    /// Use this for initialization
    /// </summary>
	void Start () 
    {
        // Create a static refernce to the script for
        // communication etc.

        if (UnitySerialPort.Instance != null)
            unitySerialPort = UnitySerialPort.Instance;
	}
	
    /// <summary>
    /// Update is called once per frame
    /// </summary>
    void Update () 
    {
        // Get the Cartesian input (joystick/keyboard)

        float x = Input.GetAxis("Horizontal");
        float y = Input.GetAxis("Vertical");

        // If you want to send the raw values to and 
        // perform calculation on the robot you can 
        // use the following line. JV tells the receiving 
        // code that the data is just basic Joysick values.

        // string data = "J," + x + "," + y;

        // Otherwise you have two additional options,
        // the sending of Raw or Value data

        // Use the x,y input to derive the wheel speeds

        CalculateTankDrive(x, y);

        // Use the derived speeds to create a data msg.

        // To send raw data use the following:

        // string data = "R," + RawLeft + "," + RawRight;

        // And to send mapped data:

        string data = "V," + ValLeft + "," + ValRight;

        // Send the data over the SerialPort to the
        // connected robot. 
        
        // First we must check that we have a serial 
        // port and that it is open.

        if (unitySerialPort.SerialPort != null && unitySerialPort.SerialPort.IsOpen)
            unitySerialPort.SerialPort.WriteLine(data);
    }

    /// <summary>
    /// This is a function used to calcuate the speed and direction
    /// values needed to provide tank drive based motion from a
    /// cartesian style input.
    /// </summary>
    /// <param name="x">cartesian x</param>
    /// <param name="y">cartesian y</param>
    /// <returns></returns>
    public void CalculateTankDrive(float x, float y)
    {
        // first Compute the angle in deg

        // First hypotenuse

        var z = Mathf.Sqrt(x * x + y * y);

        // angle in radians

        var rad = Mathf.Acos(Mathf.Abs(x) / z);

        if (float.IsNaN(rad))
            rad = 0;

        // and in degrees

        var angle = rad * 180 / Mathf.PI;

        // Now angle indicates the measure of turn
        // Along a straight line, with an angle o, the turn co-efficient is same
        // this applies for angles between 0-90, with angle 0 the co-eff is -1
        // with angle 45, the co-efficient is 0 and with angle 90, it is 1

        var tcoeff = -1 + (angle / 90) * 2;
        var turn = tcoeff * Mathf.Abs(Mathf.Abs(y) - Mathf.Abs(x));
        turn = Mathf.Round(turn * 100) / 100;

        // And max of y or x is the movement

        var move = Mathf.Max(Mathf.Abs(y), Mathf.Abs(x));

        // First and third quadrant

        if ((x >= 0 && y >= 0) || (x < 0 && y < 0))
        { rawLeft = move; rawRight = turn; }
        else
        { rawRight = move; rawLeft = turn; }

        // Reverse polarity

        if (y < 0) { rawLeft = 0 - rawLeft; rawRight = 0 - rawRight; }

        RawLeft = rawLeft;
        RawRight = rawRight;

        ValLeft = Remap(rawLeft, MinJoy, MaxJoy, MinValue, MaxValue);
        ValRight = Remap(rawRight, MinJoy, MaxJoy, MinValue, MaxValue);
    }

    /// <summary>
    /// This function is a C# version of the arduino Map function.
    /// The function maps a number from one range to another. That 
    /// is, a value of from1 would get mapped to from2, a value of 
    /// to1 to to2, values in-between to values in-between, etc.
    /// </summary>
    /// <param name="value">The Value to be mapped</param>
    /// <param name="from1">The Min of the original range</param>
    /// <param name="to1">The Max of the original range</param>
    /// <param name="from2">The Min of the range to be mapped to</param>
    /// <param name="to2">The Max of the range to be mapped to</param>
    /// <returns></returns>
    public float Remap(float value, float from1, float to1, float from2, float to2)
    {
        return (value - from1) / (to1 - from1) * (to2 - from2) + from2;
    }
}
