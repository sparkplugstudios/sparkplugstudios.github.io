﻿using System;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;
using SecretLabs.NETMF.Hardware;

using SecretLabs.NETMF.Hardware.Netduino;
// using SecretLabs.NETMF.Hardware.NetduinoPlus;

using System.IO;
using System.IO.Ports;

using System.Diagnostics;

namespace SPH_Netduino
{
    public class Program
    {
        #region Properties

        // The serial port
        private static NetduinoSPH netduinoSPH;

        // Input thread
        public static Thread inputUpdateThread;
        public static bool inputUpdate = false;

        // Output button
        private static InterruptPort button;

        #endregion Properties

        #region Program

        /// <summary>
        /// Default program constructor/entry
        /// </summary>
        public static void Main()
        {
            // Set up button
            button = new InterruptPort(
                Pins.ONBOARD_SW1, 
                false, 
                Port.ResistorMode.Disabled, 
                Port.InterruptMode.InterruptEdgeBoth
                );

            // Create EventHandler for button-press
            button.OnInterrupt += new NativeEventHandler(button_OnInterrupt);

            // Set up port
            InitialiseSerialLink();

            // Loop forever
            while (true) { }
        }

        #endregion Program

        #region SerialPort

        /// <summary>
        /// Create and open the serialport and input thread
        /// </summary>
        private static void InitialiseSerialLink()
        {
            netduinoSPH = new NetduinoSPH(SerialPorts.COM1, 9600, Parity.None, 8, StopBits.One);

            inputUpdate = true;
            inputUpdateThread = new Thread(new ThreadStart(InputUpdateThread));
            inputUpdateThread.Start();
        }

        #endregion SerialPort

        #region Input

        /// <summary>
        /// Call input thread - main serial loop for the application
        /// </summary>
        private static void InputUpdateThread()
        {
            while (inputUpdate)
            {
                try
                {
                    InputUpdate();
                }
                catch (Exception ex)
                {
                    Debug.Print(ex.Message.ToString());
                }
            }
        }

        /// <summary>
        /// Perform serial input update read
        /// </summary>
        public static void InputUpdate()
        {
            if (netduinoSPH == null) { return; }

            string inBound = netduinoSPH.ReadLine();

            if (inBound == "" || inBound == null) { return; }

            DoSomethingWithData(inBound);
        }

        #endregion Input

        #region Action

        /// <summary>
        /// Filter and do something with read data
        /// </summary>
        /// <param name="inBound"></param>
        private static void DoSomethingWithData(string inBound)
        {
            string[] data = inBound.Split(',');

            if (data.Length == 0) { return; }

            switch (data[0])
            {
                case "Open": netduinoSPH.PrintLine("Open");
                    break;
                case "A": netduinoSPH.PrintLine("Automatic");
                    break;
                case "T": DoTriggerUpdate(data);
                    break;
                case "M": DoMotorUpdate(data);
                    break;

                default: netduinoSPH.PrintLine(inBound); break;
            }

            Debug.Print(inBound);
        }

        /// <summary>
        /// Example action 1
        /// </summary>
        /// <param name="data"></param>
        private static void DoMotorUpdate(string[] data)
        {
            netduinoSPH.PrintLine("Motor Update");
        }

        /// <summary>
        /// Example action 2
        /// </summary>
        /// <param name="data"></param>
        private static void DoTriggerUpdate(string[] data)
        {
            netduinoSPH.PrintLine("Trigger Update");
        }

        #endregion Action

        #region Buttons

        /// <summary>
        /// Send button event to system
        /// </summary>
        /// <param name="data1"></param>
        /// <param name="data2"></param>
        /// <param name="time"></param>
        private static void button_OnInterrupt(uint data1, uint data2, DateTime time)
        {
            if (data2 == 0) { netduinoSPH.PrintLine("Button Pressed"); }
            if (data2 == 1) { netduinoSPH.PrintLine("Button Released"); }
        }

        #endregion Buttons
    }
}
