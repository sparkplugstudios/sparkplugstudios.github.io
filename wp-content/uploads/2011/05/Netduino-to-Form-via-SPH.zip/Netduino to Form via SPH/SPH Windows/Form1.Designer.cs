﻿namespace SPH_Windows
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.com_port_combo = new System.Windows.Forms.ComboBox();
            this.input_text = new System.Windows.Forms.TextBox();
            this.output_text = new System.Windows.Forms.TextBox();
            this.send_netduino_button = new System.Windows.Forms.Button();
            this.open_connection_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Ping: ";
            // 
            // com_port_combo
            // 
            this.com_port_combo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.com_port_combo.FormattingEnabled = true;
            this.com_port_combo.Location = new System.Drawing.Point(12, 12);
            this.com_port_combo.Name = "com_port_combo";
            this.com_port_combo.Size = new System.Drawing.Size(260, 21);
            this.com_port_combo.TabIndex = 8;
            // 
            // input_text
            // 
            this.input_text.Location = new System.Drawing.Point(11, 95);
            this.input_text.Multiline = true;
            this.input_text.Name = "input_text";
            this.input_text.ReadOnly = true;
            this.input_text.Size = new System.Drawing.Size(260, 50);
            this.input_text.TabIndex = 7;
            // 
            // output_text
            // 
            this.output_text.Location = new System.Drawing.Point(12, 39);
            this.output_text.Multiline = true;
            this.output_text.Name = "output_text";
            this.output_text.Size = new System.Drawing.Size(260, 50);
            this.output_text.TabIndex = 6;
            // 
            // send_netduino_button
            // 
            this.send_netduino_button.Location = new System.Drawing.Point(211, 152);
            this.send_netduino_button.Name = "send_netduino_button";
            this.send_netduino_button.Size = new System.Drawing.Size(60, 23);
            this.send_netduino_button.TabIndex = 5;
            this.send_netduino_button.Text = "Send";
            this.send_netduino_button.UseVisualStyleBackColor = true;
            this.send_netduino_button.Click += new System.EventHandler(this.SendToNetduinoButton_Click);
            // 
            // open_connection_button
            // 
            this.open_connection_button.Location = new System.Drawing.Point(145, 152);
            this.open_connection_button.Name = "open_connection_button";
            this.open_connection_button.Size = new System.Drawing.Size(60, 23);
            this.open_connection_button.TabIndex = 10;
            this.open_connection_button.Text = "Connect";
            this.open_connection_button.UseVisualStyleBackColor = true;
            this.open_connection_button.Click += new System.EventHandler(this.OpenConnectionButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 184);
            this.Controls.Add(this.open_connection_button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.com_port_combo);
            this.Controls.Add(this.input_text);
            this.Controls.Add(this.output_text);
            this.Controls.Add(this.send_netduino_button);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.HelpButton = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Netduino SPH Example";
            this.HelpButtonClicked += new System.ComponentModel.CancelEventHandler(this.HelpButton_Click);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox com_port_combo;
        private System.Windows.Forms.TextBox input_text;
        private System.Windows.Forms.TextBox output_text;
        private System.Windows.Forms.Button send_netduino_button;
        private System.Windows.Forms.Button open_connection_button;
    }
}

