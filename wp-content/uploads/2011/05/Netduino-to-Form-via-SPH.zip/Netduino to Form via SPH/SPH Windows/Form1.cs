﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Threading;
using System.Diagnostics;

using System.IO;
using System.IO.Ports;

namespace SPH_Windows
{
    public partial class Form1 : Form
    {
        #region Properties

        // The serial port
        private static WindowsSPH windowsSPH;

        // Available com-ports
        private static List<string> SerialPortList;

        // Input thread
        private static Thread inputUpdateThread;
        private static bool inputUpdate = false;

        // Archive write start-time
        private static DateTime startPing;

        // Connections open
        private static bool OpenConnection = false;

        #endregion Properties

        #region Form

        /// <summary>
        /// Default form constructor
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initialises the form and perform com-ports check
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            send_netduino_button.Enabled = false;
            open_connection_button.Enabled = false;

            // Poll serial ports and disable if none found
            if (!SerialPortPoll())
            {
                MessageBox.Show(
                    "A Com-Port is needed to use this application!",
                    "Com-Port Error!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                    );

                return;
            }

            open_connection_button.Enabled = true;
        }

        /// <summary>
        /// Close and cleanup perfomed here
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Kill input thread - handled via (inputUpdate && !this.Disposing && !this.IsDisposed)
            // but just in case set inputUpdate to false
            inputUpdate = false;
        }

        #endregion Form

        #region SerialPort

        /// <summary>
        /// Checks system for avaliable com-ports
        /// </summary>
        /// <returns></returns>
        private bool SerialPortPoll()
        {
            SerialPortList = new List<string>();

            // Poll system for serial ports
            foreach (string name in SerialPort.GetPortNames())
            {
                SerialPortList.Add(name);
                com_port_combo.Items.Add(name);
            }

            // If serial ports found then return true;
            if (SerialPortList.Count > 0)
            {
                com_port_combo.SelectedIndex = 0;
                return true;
            }
            else
            {
                // No ports found return false
                return false;
            }
        }

        /// <summary>
        /// Create and open the serialport and input thread
        /// </summary>
        private void InitialiseSerialLink()
        {
            // If serialport exists clean up any instances
            if (windowsSPH != null) 
            {
                windowsSPH.CloseSerialPort();
                OpenConnection = false;
                inputUpdate = false;
            }

            // Create new serialport
            windowsSPH =
                new WindowsSPH(
                com_port_combo.SelectedItem.ToString(),
                9600,
                Parity.None,
                8,
                StopBits.One
                );

            // Create input update thread
            inputUpdate = true;
            inputUpdateThread = new Thread(new ParameterizedThreadStart(InputUpdateThread));
            inputUpdateThread.Start();
        }

        /// <summary>
        /// Enable send button
        /// </summary>
        private void OpenConnections()
        {
            // Update connection state
            OpenConnection = true;

            // Enable send button cross thread
            Invoke((MethodInvoker)delegate()
            { send_netduino_button.Enabled = true; });
        }

        #endregion SerialPort

        #region Input

        /// <summary>
        /// Call input thread - main serial loop for the application
        /// </summary>
        /// <param name="param"></param>
        private void InputUpdateThread(object param)
        {
            while (inputUpdate && !this.Disposing && !this.IsDisposed)
            {
                try
                {
                    // Search for serial connection
                    if (OpenConnection == false)
                    {
                        startPing = DateTime.Now;
                        windowsSPH.PrintLine("Open");
                        Thread.Sleep(100);
                    }

                    // Call input update if connection found
                    InputUpdate();
                }
                catch (Exception ex)
                {
                    if (this.IsDisposed) { return; }
                    Debug.Print(ex.Message.ToString());
                }
            }
        }

        /// <summary>
        /// Perform serial input update read
        /// </summary>
        public void InputUpdate()
        {
            if (windowsSPH == null) { return; }

            // Read from serialport
            string inBound = windowsSPH.ReadLine();

            // Return if data is null/void
            if (inBound == "" || inBound == null) { return; }

            // Remove faux data
            string[] items = inBound.Split('\0');
            inBound = items[0];

            // Filter the data and perform actions
            DoSomethingWithData(inBound);

            // Output data to the GUI
            DisplayData(inBound);
        }

        /// <summary>
        /// Function used to display data sent via the netduino to the form
        /// </summary>
        /// <param name="inBound"></param>
        private void DisplayData(string inBound)
        {
            Invoke((MethodInvoker)delegate()
            {
                label1.Text = "Ping: " + (DateTime.Now - startPing).ToString();

                if (inBound == "Open")
                {
                    input_text.Text = "Connections Now Open!";
                }
                else
                {
                    input_text.Text = inBound;
                }
            });
        }

        #endregion Input

        #region Action

        /// <summary>
        /// Filter and do something with read data
        /// </summary>
        /// <param name="inBound"></param>
        private void DoSomethingWithData(string inBound)
        {
            // Seperate data from string
            string[] data = inBound.Split(',');

            if (data.Count() == 0) { return; }

            // Filter input data and call/perform action
            switch (data[0])
            {
                case "Open": OpenConnections();
                    break;
                case "M": Debug.WriteLine("Manual");
                    break;
                case "A": Debug.WriteLine("Automatic");
                    break;
            }
        }

        #endregion Action

        #region Buttons

        /// <summary>
        /// Function used to send data to the netduino
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SendToNetduinoButton_Click(object sender, EventArgs e)
        {
            startPing = DateTime.Now;
            windowsSPH.PrintLine(output_text.Text);
        }

        /// <summary>
        /// Function used to call initialise connection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenConnectionButton_Click(object sender, EventArgs e)
        {
            InitialiseSerialLink();
        }

        /// <summary>
        /// Visit my website for more info
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HelpButton_Click(object sender, CancelEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.dyadica.net/journal");
        }

        #endregion Buttons
    }
}
