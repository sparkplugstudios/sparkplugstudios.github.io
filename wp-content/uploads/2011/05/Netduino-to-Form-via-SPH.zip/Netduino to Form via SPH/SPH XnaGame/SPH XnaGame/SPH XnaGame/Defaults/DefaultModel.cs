﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace SPH_XnaGame
{
    public class DefaultModel
    {
        public Game1 game; 
        public Model model;
        public Matrix world;
        public Matrix pV, rX, rY, rZ;

        public Vector3 position = new Vector3(0, 0, 0);
        public Vector3 rotation = new Vector3(0, 0, 0);

        public Vector3 scale = new Vector3(1, 1, 1);

        public bool pinching = false;

        public Vector3 DiffuseColor;
        public Vector3 arcDiffuseColor = Color.White.ToVector3();

        public float FogStart = 800f;
        public float FogEnd = 2000f;
        public bool FogEnabled = true;
        public Vector3 FogColor = Color.Black.ToVector3();

        public bool released = false;

        public float Alpha = 1.0f;

        public bool Visible = true;

        public Texture2D textureA, textureB, texture0, texture1, defTextureA, defTextureB;

        /////////////////////////////////////////////////////////////

        public DefaultModel()
        {
        }

        public DefaultModel(Model md, Game1 gme)
        {
            game = gme; model = md; DiffuseColor = arcDiffuseColor;
            InitialiseModel();
        }

        public DefaultModel(Model md, Game1 gme, Texture2D a, Texture2D b)
        {
            game = gme; model = md; DiffuseColor = arcDiffuseColor;
            textureA = a; textureB = b; 
            InitialiseModel();
        }

        public virtual void InitialiseModel()
        {
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (Effect effect in mesh.Effects)
                {
                    if (effect is BasicEffect)
                    {
                        BasicEffect be = effect as BasicEffect;
                        texture0 = be.Texture; defTextureA = be.Texture;
                    }
                    else if (effect is DualTextureEffect)
                    {
                        DualTextureEffect de = effect as DualTextureEffect;
                        defTextureA = de.Texture; defTextureB = de.Texture2;
                        texture0 = defTextureA; texture1 = defTextureB;
                    }
                }
            }
        }

        /////////////////////////////////////////////////////////////

        public virtual void UpdateModel()
        {
            foreach (ModelMesh mesh in model.Meshes)
            {
                // Set pV 
                pV = Matrix.CreateTranslation(position);
                // Set rX, rY, rZ
                rX = Matrix.CreateRotationX(MathHelper.ToRadians(rotation.X));
                rY = Matrix.CreateRotationY(MathHelper.ToRadians(rotation.Y));
                rZ = Matrix.CreateRotationZ(MathHelper.ToRadians(rotation.Z));                
            }
        }

        public virtual void DrawModel()
        {
            Matrix[] transforms = new Matrix[model.Bones.Count];
            model.CopyAbsoluteBoneTransformsTo(transforms);
            world = Matrix.CreateScale(scale) * rX * rY * rZ * pV;            

            foreach (ModelMesh mesh in model.Meshes)
            {
                #region Dynamic Effect System

                foreach (Effect effect in mesh.Effects)
                {
                    if (effect is BasicEffect)
                    {
                        BasicEffect be = effect as BasicEffect;
                        be.DiffuseColor = DiffuseColor;
                        be.Alpha = Alpha;
                        be.EnableDefaultLighting();
                        be.Texture = texture0;
                        DrawFog(mesh);                       
                        UpdateMatricies(mesh, transforms);
                    }
                    else if (effect is DualTextureEffect)
                    {
                        DualTextureEffect de = effect as DualTextureEffect;
                        de.DiffuseColor = DiffuseColor;
                        de.Alpha = Alpha;
                        de.Texture = texture0;
                        de.Texture2 = texture1;
                        DrawFog(mesh);                       
                        UpdateMatricies(mesh, transforms);
                    }
                    else if (effect is EnvironmentMapEffect)
                    {
                        EnvironmentMapEffect ee = effect as EnvironmentMapEffect;
                        ee.DiffuseColor = DiffuseColor;
                        ee.Alpha = Alpha;
                        DrawFog(mesh);
                        UpdateMatricies(mesh, transforms);
                    }
                    else if (effect is AlphaTestEffect)
                    {
                        AlphaTestEffect ae = effect as AlphaTestEffect;
                        ae.DiffuseColor = DiffuseColor;
                        ae.Alpha = Alpha;
                        DrawFog(mesh);
                        UpdateMatricies(mesh, transforms);
                    }
                    else if (effect is SkinnedEffect)
                    {
                        SkinnedEffect se = effect as SkinnedEffect;
                        se.DiffuseColor = DiffuseColor;
                        se.Alpha = Alpha;
                        DrawFog(mesh);
                        UpdateMatricies(mesh, transforms);
                    }
                    else
                    {
                        effect.Parameters["World"].SetValue(transforms[mesh.ParentBone.Index] * world);
                        effect.Parameters["View"].SetValue(game.currentCamera.viewMatrix);
                        effect.Parameters["Projection"].SetValue(game.currentCamera.projectionMatrix);
                    }                    
                }
                
                #endregion Dynamic Effect System

                if (Visible) { mesh.Draw(); }
            }
        }

        /////////////////////////////////////////////////////////////

        void DrawFog(ModelMesh mesh)
        {
            foreach (IEffectFog effect in mesh.Effects)
            {
                effect.FogEnabled = FogEnabled;
                effect.FogColor = FogColor;
                effect.FogStart = FogStart;
                effect.FogEnd = FogEnd;
            }
        }

        void UpdateMatricies(ModelMesh mesh, Matrix[] transforms)
        {
            foreach (IEffectMatrices effect in mesh.Effects)
            {
                effect.World = transforms[mesh.ParentBone.Index] * world;
                effect.View = game.currentCamera.viewMatrix;
                effect.Projection = game.currentCamera.projectionMatrix;
            }
        }

        /////////////////////////////////////////////////////////////
    }
}
