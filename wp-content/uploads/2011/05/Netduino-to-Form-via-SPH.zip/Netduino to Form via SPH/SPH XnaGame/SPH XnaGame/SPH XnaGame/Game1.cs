using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using System.Threading;
using System.Diagnostics;

using System.IO;
using System.IO.Ports;

using System.Windows.Forms;

namespace SPH_XnaGame
{
    // Resolve Windows Forms and Xna Conflicts
    using Keyboard = Microsoft.Xna.Framework.Input.Keyboard;
    using Mouse = Microsoft.Xna.Framework.Input.Mouse;
    using GamePad = Microsoft.Xna.Framework.Input.GamePad;
    using ButtonState = Microsoft.Xna.Framework.Input.ButtonState;
    using Keys = Microsoft.Xna.Framework.Input.Keys;

    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        // The serial port
        private static WindowsSPH windowsSPH;

        // Available com-ports
        private static List<string> SerialPortList;

        // Input thread
        private static Thread inputUpdateThread;
        private static bool inputUpdate = false;

        // Archive write start-time
        private static DateTime startPing;

        // Connections open
        private static bool OpenConnection = false;

        // Netduino button state
        private bool netduinoButtonPressed = false;

        // Model Dictionary
        public Dictionary<string, DefaultModel> modelDictionary 
            = new Dictionary<string,DefaultModel>();

        public DefaultCamera currentCamera;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        #region SerialPort

        /// <summary>
        /// Checks system for avaliable com-ports
        /// </summary>
        /// <returns></returns>
        private bool SerialPortPoll()
        {
            SerialPortList = new List<string>();

            // Poll system for serial ports
            foreach (string name in SerialPort.GetPortNames())
            { SerialPortList.Add(name); }

            // If serial ports found then return true;
            if (SerialPortList.Count > 0)
            { return true; }
            else { return false; }
        }

        /// <summary>
        /// Create and open the serialport and input thread
        /// </summary>
        private void InitialiseSerialLink()
        {
            // If serialport exists clean up any instances
            if (windowsSPH != null)
            {
                windowsSPH.CloseSerialPort();
                OpenConnection = false;
                // Uncomment to run via thread
                // inputUpdate = false;
            }

            // Create new serialport via default port (1st found)
            windowsSPH =
                new WindowsSPH(
                SerialPortList[0],
                9600,
                Parity.None,
                8,
                StopBits.One
                );

            // Create input update thread - Uncomment to run via thread
            //inputUpdate = true;
            //inputUpdateThread = new Thread(new ParameterizedThreadStart(InputUpdateThread));
            //inputUpdateThread.Start();
        }

        /// <summary>
        /// Call input thread - main serial loop for the application
        /// </summary>
        /// <param name="param"></param>
        private void InputUpdateThread(object param)
        {
            while (inputUpdate)
            {
                PerformSerialUpdate();
            }
        }

        /// <summary>
        /// Wrapper for serial update function
        /// </summary>
        private void PerformSerialUpdate()
        {
            try
            {
                // Poll to see if we have a port
                if (SerialPortList.Count == 0) { return; }

                // Search for serial connection
                if (OpenConnection == false)
                {
                    startPing = DateTime.Now;
                    windowsSPH.PrintLine("Open");
                    Thread.Sleep(100);
                }

                // Call input update if connection found
                SerialInputUpdate();
            }
            catch (Exception ex)
            {
                Debug.Print(ex.Message.ToString());
            }
        }

        /// <summary>
        /// Perform serial input update read
        /// </summary>
        public void SerialInputUpdate()
        {
            if (windowsSPH == null) { return; }

            // Read from serialport
            string inBound = windowsSPH.ReadLine();

            // Return if data is null/void
            if (inBound == "" || inBound == null) { return; }

            // Remove faux data
            string[] items = inBound.Split('\0');
            inBound = items[0];

            // Filter the data and perform actions
            DoSomethingWithData(inBound);

            // Un-comment to display input via output window
            // Debug.WriteLine(inBound);
        }

        /// <summary>
        /// Filter and do something with read data
        /// </summary>
        /// <param name="inBound"></param>
        private void DoSomethingWithData(string inBound)
        {
            // Seperate data from string
            string[] data = inBound.Split(',');

            if (data.Count() == 0) { return; }

            // Filter input data and call/perform action
            switch (data[0])
            {
                case "Open":
                    OpenConnection = true;
                    Debug.WriteLine("Connections are open!");
                    break;
                case "M": Debug.WriteLine("Manual");
                    break;
                case "A": Debug.WriteLine("Automatic");
                    break;
                case "Button Pressed": netduinoButtonPressed = true;
                    break;
                case "Button Released": netduinoButtonPressed = false;
                    break;
            }
        }

        #endregion SerialPort

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            DepthStencilState depthStencilState = new DepthStencilState();
            depthStencilState.DepthBufferEnable = true;

            graphics.GraphicsDevice.DepthStencilState = depthStencilState;


            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here

            #region SerialPort

            // Poll serial ports and disable if none found
            if (!SerialPortPoll())
            {
                MessageBox.Show(
                    "A Com-Port is needed to use this application!",
                    "Com-Port Error!",
                    MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Information
                    );

                return;
            }
            else
            {
                // If found initialise the port
                InitialiseSerialLink();
            }

            #endregion SerialPort

            // Load Scene models and add to model dictionary
            modelDictionary.Add("Box", new DefaultModel(Content.Load<Model>(@"Models\Box_1M"), this));
            modelDictionary.Add("Plane", new DefaultModel(Content.Load<Model>(@"Models\GroundPlaneBlue"), this));

            // Create scene camera
            currentCamera = new DefaultCamera(
                    this,
                    new Vector3(0, 250, 800),
                    new Vector3(0, 250, -1),
                    Vector3.UnitY,
                    1.0f,
                    10000.0f,
                    MathHelper.PiOver4
                    );
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here

            if (inputUpdateThread != null) { inputUpdate = false; }
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here

            // Poll the serial connection for input from netduino
            // Comment out if running via thread
            PerformSerialUpdate();

            // currentCamera.UpdateCreatePerspectiveFieldOfView(gameTime);

            // Additional example for input action
            if (netduinoButtonPressed)
            {
                // Move model up on press
                modelDictionary["Box"].position.Y += 5;
            }
            else
            {
                // Faux gravity on release
                modelDictionary["Box"].position.Y -= 40;

                // Dont let box drop below zero
                if (modelDictionary["Box"].position.Y < 0)
                { modelDictionary["Box"].position.Y = 0; }
            }

            // Update the model
            foreach (KeyValuePair<string, DefaultModel> dm in modelDictionary)
            { dm.Value.UpdateModel(); }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here

            graphics.GraphicsDevice.BlendState = BlendState.AlphaBlend;
            graphics.GraphicsDevice.DepthStencilState = DepthStencilState.Default;
            graphics.GraphicsDevice.SamplerStates[0] = SamplerState.LinearWrap;

            // Draw all models in model dictionary
            foreach (KeyValuePair<string, DefaultModel> dm in modelDictionary )
            { dm.Value.DrawModel(); }

            spriteBatch.Begin();
            // Call 2D graphics draws here
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
