﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SPH_XnaGame
{
    public class DefaultCamera
    {
        public Game1 game;

        // projectionMatrix defaults
        public float nearPlane = 1.0f;
        public float farPlane = 1000.0f;
        public float fieldOfView = 45.0f;

        // Camera matrices
        public Matrix viewMatrix;
        public Matrix projectionMatrix;
        public float aspectRatio;

        // Camera vectors
        public Vector3 position;
        public Vector3 target;
        public Vector3 direction;
        public Vector3 cameraUp;

        // Camera rotations
        public float cameraYaw = 0.0f;
        public float cameraPitch = 0.0f;
        public float cameraRoll = 0.0f;

        // Camera rotations
        public float cameraYawLimit = 0.0f;
        public float cameraPitchLimit = 89.0f;
        public float cameraRollLimit = 45.0f;

        //
        public Vector3 cameraPosition;
        public Vector3 cameraTarget;
        public Vector3 cameraDirection;

        public float cameraNear, cameraFar, cameraFov;
        
        public Vector3 cameraUpv;

        public float left = -1f;
        public float right = 1f;
        public float bottom = -1f;
        public float top = 1f;

        // public virtual int pcam = 1;

        public DefaultCamera() { }

        public DefaultCamera(Game1 gm, Vector3 pos, Vector3 tgt, Vector3 upv, float np, float fp, float fov)
        {
            game = gm;
            cameraPosition = pos; cameraTarget = tgt; cameraDirection = cameraTarget - cameraPosition;
            cameraNear = np; cameraFar = fp; cameraFov = fov; cameraUpv = upv;

            aspectRatio = (float)game.GraphicsDevice.Viewport.AspectRatio;

            viewMatrix = Matrix.CreateLookAt(cameraPosition, cameraTarget, cameraUpv);
            projectionMatrix = Matrix.CreatePerspectiveFieldOfView(cameraFov, aspectRatio, cameraNear, cameraFar);
        }

        public virtual void InitialiseCamera()
        {
        }

        public virtual void Update(GameTime gameTime)
        {
        }

        public virtual void UpdateCreatePerspectiveFieldOfView(GameTime gameTime)
        {
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;
            viewMatrix = Matrix.CreateLookAt(cameraPosition, cameraTarget, cameraUpv);
            projectionMatrix = Matrix.CreatePerspectiveFieldOfView(cameraFov, aspectRatio, cameraNear, cameraFar);
        }

        public virtual void UpdateCreatePerspectiveOffCenter(GameTime gameTime)
        {
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;
            viewMatrix = Matrix.CreateLookAt(cameraPosition, cameraTarget, cameraUpv);
            projectionMatrix = Matrix.CreatePerspectiveOffCenter(left, right, bottom, top, cameraNear, cameraFar);
        }

        public Matrix GetCreatePerspectiveFieldOfView()
        {
            Matrix m = Matrix.CreatePerspectiveFieldOfView(cameraFov, aspectRatio, cameraNear, cameraFar);
            return m;
        }

        public Matrix GetCreatePerspectiveOffCenter()
        {
            Matrix m = Matrix.CreatePerspectiveOffCenter(left, right, bottom, top, cameraNear, cameraFar);
            return m;
        }

        public virtual void Draw(GameTime gameTime)
        {
        }

        #region viewMatrix/Direction Matrix

        public Matrix CreateviewMatrixMatrix()
        {
            Matrix m = Matrix.CreateLookAt(position,
                target, cameraUp);
            return m;
        }

        public Matrix CreateLookMatrix()
        {
            Matrix m = Matrix.CreateLookAt(position,
                position + target, cameraUp);
            return m;
        }

        public Matrix GetCameraDirectionMatrix()
        {
            Matrix m = Matrix.CreateWorld(
                viewMatrix.Right, target, viewMatrix.Up);
            return m;
        }

        #endregion viewMatrix/Direction Matrix
    }
}
